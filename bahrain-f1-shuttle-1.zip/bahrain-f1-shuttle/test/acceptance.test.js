'use strict';
// Run with: npm test   (uses Node's built-in test runner, no dependencies)
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer } = require('../server');

// Controllable clock: start at 1 Oct 2026, 12:00 MYT.
let clock = Date.parse('2026-10-01T12:00:00+08:00');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bfms-'));
let server, base, adminCookie, csrf;

const post = (p, body, headers = {}) => fetch(base + p, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) });
const adminFetch = (p, opts = {}) => fetch(base + p, { ...opts, headers: { 'Content-Type': 'application/json', Cookie: adminCookie, 'X-CSRF-Token': csrf, ...(opts.headers || {}) } });
const book = (o = {}) => post('/api/bookings', { name: 'Ahmad Faiz', phone: '012-3456789', date: '2026-10-03', route: 'SIC_MOP', time: '07:00', citizen: true, ...o });
const slotStatus = async (date, route, time) => {
  const a = await (await fetch(`${base}/api/availability?date=${date}&route=${route}`)).json();
  return [...a.morning, ...a.evening].find((s) => s.time === time).status;
};

before(async () => {
  server = createServer({ dbFile: path.join(dir, 'test.db'), now: () => clock, rateLimits: { booking: 1000, lookup: 1000, login: 1000 } });
  await server.store.createAdmin('ops', 'correct-horse-battery');
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
  const res = await post('/api/admin/login', { username: 'ops', password: 'correct-horse-battery' });
  adminCookie = res.headers.get('set-cookie').split(';')[0];
  csrf = (await res.json()).csrfToken;
});
after(() => { server.close(); server.store.close(); fs.rmSync(dir, { recursive: true, force: true }); });

let firstBooking;
test('TEST 1 — normal booking locks the slot', async () => {
  const res = await book();
  assert.equal(res.status, 201);
  firstBooking = (await res.json()).booking;
  assert.match(firstBooking.bookingId, /^BFMS-3OCT-7A-[A-Z2-9]{4}$/);
  assert.equal(firstBooking.fare, 30);
  assert.equal(await slotStatus('2026-10-03', 'SIC_MOP', '07:00'), 'BOOKED');
});

test('TEST 2 — duplicate booking of the same slot is rejected', async () => {
  const res = await book({ name: 'Siti Aminah', phone: '0198765432' });
  assert.equal(res.status, 409);
  const body = await res.json();
  assert.equal(body.error.code, 'SLOT_TAKEN');
  assert.match(body.error.message, /This slot is no longer available/);
  assert.ok(!JSON.stringify(body).includes('Ahmad'), 'must not leak the other passenger');
});

test('TEST 3 — same date and time on the other route is allowed', async () => {
  assert.equal((await book({ route: 'MOP_SIC', phone: '011-12345678' })).status, 201);
});

test('TEST 4 — same route and time on a different date is allowed', async () => {
  assert.equal((await book({ date: '2026-10-04', phone: '0131234567' })).status, 201);
});

test('TEST 5 — customer cancellation releases the slot and keeps the record', async () => {
  const find = await post('/api/bookings/find', { bookingId: firstBooking.bookingId.toLowerCase(), phone: '+60 12-345 6789' });
  assert.equal(find.status, 200);
  const res = await post('/api/bookings/cancel', { bookingId: firstBooking.bookingId, phone: '0123456789' });
  assert.equal(res.status, 200);
  assert.equal((await res.json()).booking.status, 'CANCELLED');
  assert.equal(await slotStatus('2026-10-03', 'SIC_MOP', '07:00'), 'AVAILABLE');
  const list = await (await adminFetch(`/api/admin/bookings?q=${firstBooking.bookingId}`)).json();
  assert.equal(list.bookings[0].status, 'CANCELLED');
});

test('TEST 6 — wrong cancellation details reveal nothing', async () => {
  for (const body of [{ bookingId: 'BFMS-3OCT-7A-ZZZZ', phone: '0123456789' }, { bookingId: firstBooking.bookingId, phone: '0199999999' }]) {
    const res = await post('/api/bookings/cancel', body);
    assert.equal(res.status, 404);
    const j = await res.json();
    assert.match(j.error.message, /We couldn't find a matching booking/);
    assert.ok(!j.booking);
  }
});

test('TEST 7 — booking closes exactly 1 hour before pickup (Malaysia time)', async () => {
  clock = Date.parse('2026-10-03T05:59:59+08:00');
  assert.equal(await slotStatus('2026-10-03', 'SIC_MOP', '07:30'), 'AVAILABLE');
  clock = Date.parse('2026-10-03T06:30:00+08:00'); // exactly 1h before 07:30
  assert.equal(await slotStatus('2026-10-03', 'SIC_MOP', '07:30'), 'CLOSED');
  const res = await book({ time: '07:30', phone: '0141111111' });
  assert.equal(res.status, 409);
  assert.equal((await res.json()).error.code, 'BOOKING_CLOSED');
  assert.equal((await book({ time: '08:00', phone: '0141111111' })).status, 201, 'later slot still open');
  clock = Date.parse('2026-10-01T12:00:00+08:00');
});

test('TEST 8 — simultaneous bookings: exactly one succeeds', async () => {
  const attempts = Array.from({ length: 25 }, (_, i) => book({ time: '09:00', phone: `017${String(1000000 + i)}`, name: `Racer ${i + 1}` }));
  const statuses = (await Promise.all(attempts)).map((r) => r.status);
  assert.equal(statuses.filter((s) => s === 201).length, 1);
  assert.equal(statuses.filter((s) => s === 409).length, 24);
  const rows = server.store.db.prepare("SELECT COUNT(*) n FROM bookings WHERE date='2026-10-03' AND route='SIC_MOP' AND pickup_time='09:00' AND status='CONFIRMED'").get();
  assert.equal(rows.n, 1);
});

test('TEST 9 — admin reopens a booked slot', async () => {
  const res = await adminFetch('/api/admin/slots/reopen', { method: 'POST', body: JSON.stringify({ date: '2026-10-03', route: 'SIC_MOP', time: '09:00' }) });
  assert.equal((await res.json()).reopened, true);
  assert.equal(await slotStatus('2026-10-03', 'SIC_MOP', '09:00'), 'AVAILABLE');
  assert.equal((await book({ time: '09:00', phone: '0182222222' })).status, 201);
});

test('Double tap with the same request key returns one booking', async () => {
  const key = 'k-' + 'a'.repeat(30);
  const [a, b] = await Promise.all([book({ time: '09:30', phone: '0163333333', requestKey: key }), book({ time: '09:30', phone: '0163333333', requestKey: key })]);
  const ids = [(await a.json()).booking.bookingId, (await b.json()).booking.bookingId];
  assert.equal(ids[0], ids[1]);
});

test('Citizenship confirmation and phone validation are enforced server-side', async () => {
  assert.equal((await (await book({ time: '10:00', citizen: false })).json()).error.code, 'CITIZEN_REQUIRED');
  assert.equal((await (await book({ time: '10:00', phone: '12345' })).json()).error.code, 'INVALID_PHONE');
  assert.equal((await (await book({ time: '10:00', date: '2026-10-05' })).json()).error.code, 'INVALID_SLOT');
  assert.equal((await (await book({ time: '10:15' })).json()).error.code, 'INVALID_SLOT');
});

test('Admin endpoints require a session and a CSRF token', async () => {
  assert.equal((await fetch(base + '/api/admin/bookings')).status, 401);
  const noCsrf = await fetch(base + '/api/admin/slots/reopen', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: adminCookie }, body: '{}' });
  assert.equal(noCsrf.status, 403);
  assert.equal((await post('/api/admin/login', { username: 'ops', password: 'wrong-password' })).status, 401);
  const cross = await post('/api/bookings', {}, { Origin: 'https://evil.example' });
  assert.equal(cross.status, 403);
});

test('Admin manual booking follows the same slot rule; reconfirm is blocked if slot re-taken', async () => {
  const dup = await adminFetch('/api/admin/bookings', { method: 'POST', body: JSON.stringify({ name: 'Walk In', phone: '0125555555', date: '2026-10-03', route: 'SIC_MOP', time: '09:00', citizen: true }) });
  assert.equal(dup.status, 409);
  const list = await (await adminFetch(`/api/admin/bookings?q=${firstBooking.bookingId}`)).json();
  assert.equal(list.bookings[0].status, 'CANCELLED');
  await book({ time: '07:00', phone: '0126666666' }); // someone takes the released 07:00 slot
  const re = await adminFetch(`/api/admin/bookings/${firstBooking.bookingId}/status`, { method: 'POST', body: JSON.stringify({ status: 'CONFIRMED' }) });
  assert.equal(re.status, 409);
});

test('Event dates are configurable from admin', async () => {
  const res = await adminFetch('/api/admin/settings', { method: 'PUT', body: JSON.stringify({ eventDates: ['2026-10-03', '2026-10-04', '2026-10-05'] }) });
  assert.equal(res.status, 200);
  const cfg = await (await fetch(base + '/api/config')).json();
  assert.deepEqual(cfg.dates.map((d) => d.date), ['2026-10-03', '2026-10-04', '2026-10-05']);
  assert.equal((await book({ date: '2026-10-05', phone: '0197777777' })).status, 201);
});

test('Per-phone limit stops one number booking every slot', async () => {
  const phone = '0138888888';
  const times = ['16:00', '16:30', '17:00', '17:30', '18:00'];
  const results = [];
  for (const t of times) results.push((await book({ phone, time: t, date: '2026-10-04' })).status);
  assert.deepEqual(results, [201, 201, 201, 201, 409]);
});

test('A date with confirmed bookings cannot be removed from the event dates', async () => {
  const res = await adminFetch('/api/admin/settings', { method: 'PUT', body: JSON.stringify({ eventDates: ['2026-10-03', '2026-10-04'] }) });
  assert.equal(res.status, 409); // 5 Oct still holds a confirmed booking from the test above
  const cfg = await (await fetch(base + '/api/config')).json();
  assert.equal(cfg.dates.length, 3);
});

test('Customers cannot cancel online once the pickup time has passed', async () => {
  const saved = clock;
  clock = Date.parse('2026-10-03T12:00:00+08:00');
  const b = (await (await book({ date: '2026-10-04', time: '20:00', phone: '0171231234' })).json()).booking;
  clock = Date.parse('2026-10-04T20:00:00+08:00');
  const res = await post('/api/bookings/cancel', { bookingId: b.bookingId, phone: '0171231234' });
  assert.equal(res.status, 409);
  assert.equal(await slotStatus('2026-10-04', 'SIC_MOP', '20:00'), 'BOOKED');
  clock = saved;
});
