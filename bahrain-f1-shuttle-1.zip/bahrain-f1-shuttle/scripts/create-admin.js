'use strict';
// Usage: npm run create-admin -- <username>
// Prompts for the password so it never lands in shell history.
const path = require('node:path');
const readline = require('node:readline');
const { createStore } = require('../src/store');

const username = process.argv[2];
if (!username) { console.error('Usage: npm run create-admin -- <username>'); process.exit(1); }
const file = path.join(process.env.DATA_DIR || path.join(__dirname, '..', 'data'), 'bookings.db');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
rl._writeToOutput = (s) => { if (s.includes('Password')) process.stdout.write(s); else process.stdout.write('*'); };
rl.question('Password (10+ characters): ', async (pw) => {
  rl.close(); process.stdout.write('\n');
  const store = createStore({ file });
  try { await store.createAdmin(username, pw); console.log(`Admin "${username}" created in ${file}`); }
  catch (e) { console.error(e.message); process.exitCode = 1; }
  finally { store.close(); }
});
